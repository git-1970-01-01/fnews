package com.mm.poker.record.log;

public class RecordLog {

    private static StringBuilder log = new StringBuilder();

    public static void log() {

    }

}

package com.mm.poker.record.knn;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.DoublePredicate;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.ToLongFunction;
import java.util.stream.Collectors;

/**
 * KNN識別數字 需要大量的樣本，由於屏幕分辨率導致圖像矩陣不一樣，可能導致識別失敗，後期考慮tesseract識別，或多采集數據做knn訓練樣本
 * 識別出錯，做本地保存更正后作爲訓練樣本
 */
public class KnnUtils {
    private final static int K = 3;//KNN 中 K 的值

    private static List<TrainDigitsPoint> _poker_num_o_area = new ArrayList<>();

    private static List<TrainDigitsPoint> _poker_suit_o_area = new ArrayList<>();

    private static final String[] POKER_NUM = new String[]{"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};

    private static final String[] POKER_SUIT = new String[]{"MH", "FK", "HT", "HX"};

    public static final String IDENTIFY_ERROR = "NONE";

    public static void init() {


    }


    private static void openFileInput(Context context, String prefix, String name, Consumer<List<TrainDigitsPoint>> consumer) {
        InputStream inputStream = null;
        List<TrainDigitsPoint> digitsPointList = new ArrayList<>();
        try {
            inputStream = context.getAssets().open(prefix + name + ".db");
            byte[] buffer = new byte[1024];
            while ((inputStream.read(buffer)) != -1) {
                digitsPointList.add(new TrainDigitsPoint(name, buffer));
            }
            consumer.accept(digitsPointList);
        } catch (FileNotFoundException e) {
            consumer.accept(null);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void init(Context context) {
        _poker_num_o_area.clear();

        for (String s : POKER_NUM) {
            openFileInput(context, "poker_num_o_area", s, trainDigitsPoints -> _poker_num_o_area.addAll(trainDigitsPoints));
        }
        for (String s : POKER_NUM) {
            openFileInput(context, "poker_num_extra_area", s, trainDigitsPoints -> {
                if (trainDigitsPoints != null) {
                    _poker_num_o_area.addAll(trainDigitsPoints);
                }
            });
        }
        _poker_suit_o_area.clear();
        for (String s : POKER_SUIT) {
            openFileInput(context, "poker_suit_o_area", s, trainDigitsPoints -> _poker_suit_o_area.addAll(trainDigitsPoints));
        }


    }


    private static double calDistance(byte[] a, byte[] b) {
        int temp = 0;
        for (int i = 0; i < a.length; i++) {
            temp += (a[i] - b[i]) * (a[i] - b[i]);
        }
        return temp;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public static String classify(byte[] arr, int type, boolean relieveLimit) {
        Long startTime = System.currentTimeMillis();
        double dis[] = new double[K];
        String num[] = new String[K];

        for (int index = 0; index < K; index++) {
            dis[index] = 32 * 32;
            num[index] = IDENTIFY_ERROR;
        }
        for (TrainDigitsPoint trainingDigitsPoint : type == 0 ? _poker_num_o_area : _poker_suit_o_area) {
            double temp_dis = calDistance(arr, trainingDigitsPoint.arr);
            for (int k = 0; k < K; k++) {
                //设定最小匹配距离要小于15.0
                if (temp_dis < dis[k]) {
                    dis[k] = temp_dis;
                    num[k] = trainingDigitsPoint.value;
                }
            }
        }
        Map<String, Long> map = Arrays.stream(num).collect(Collectors.groupingBy(s -> s, Collectors.counting()));
        final long max = map.values().stream().mapToLong(l -> l).max().getAsLong();
        //完全匹配才成功
        if (max == 3 && !Arrays.asList(num).contains(IDENTIFY_ERROR) && ((Arrays.stream(dis).max().getAsDouble() < 200) || relieveLimit)) {
            return map.entrySet().stream().filter(stringLongEntry -> Objects.equals(stringLongEntry.getValue(), max)).map(Map.Entry::getKey).collect(Collectors.toList()).get(0);
        }
        return IDENTIFY_ERROR;
    }


    static class TrainDigitsPoint implements Serializable {
        TrainDigitsPoint(String value, byte[] arr) {
            this.value = value;
            this.arr = arr;
        }

        String value;
        byte[] arr;
    }

}

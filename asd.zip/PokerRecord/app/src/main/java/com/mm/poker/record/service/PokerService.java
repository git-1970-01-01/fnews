package com.mm.poker.record.service;


import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.mm.poker.record.PokerRecordApplication;
import com.mm.poker.record.R;
import com.mm.poker.record.device.DeviceNumericalValue;
import com.mm.poker.record.manager.PokerManager;
import com.mm.poker.record.opencv.PokerCv;
import com.mm.poker.record.view.PokerCountView;

import org.opencv.android.Utils;
import org.opencv.core.Mat;
import org.opencv.core.Rect;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Objects;

public class PokerService extends Service {

    private static final String CHANNEL_ID = "poker_record";

    private static final String TAG = "poker_service_tag";

    private MediaProjection mMediaProjection = null;
    private VirtualDisplay mVirtualDisplay = null;
    public static MediaProjectionManager mMediaProjectionManager = null;
    private int mScreenDensity = 0;
    private int windowWidth = 0;
    private int windowHeight = 0;
    private ImageReader mImageReader = null;
    private Handler mCaptureHandler = new Handler();
    public static boolean IS_SAVE_FILE = false;
    private int mResultCode;
    private Intent mResultData;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            setForegroundService();
        }
        createVirtualEnvironment();
        startTimingCapture();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
//        mMediaProjectionManager = ((PokerRecordApplication)getApplication()).getMediaProjectionManager();
//        mResultCode = intent.getIntExtra("code", -1);
//        mResultData = intent.getParcelableExtra("data");
//        mMediaProjection = mMediaProjectionManager.getMediaProjection(mResultCode, Objects.requireNonNull(mResultData));
//        Log.e(TAG, "mMediaProjection created: " + mMediaProjection);
        return START_STICKY;
    }

    @androidx.annotation.RequiresApi(api = Build.VERSION_CODES.O)
    public void setForegroundService() {
        //设定的通知渠道名称
        String channelName = "PokerRecord";
        //设置通知的重要程度
        int importance = NotificationManager.IMPORTANCE_LOW;
        //构建通知渠道
        @SuppressLint("WrongConstant") NotificationChannel channel = new NotificationChannel(CHANNEL_ID, channelName, importance);
        channel.setDescription(channelName);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID);
        builder.setSmallIcon(R.mipmap.ic_launcher_poker_record) //设置通知图标
                .setContentTitle("扑克记牌器")//设置通知标题
                .setContentText("正在运行中...")//设置通知内容
                .setAutoCancel(false) //用户触摸时，自动关闭
                .setOngoing(true);//设置处于运行状态
        //向系统注册通知渠道，注册后不能改变重要性以及其他通知行为
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.createNotificationChannel(channel);
        //将服务置于启动状态 NOTIFICATION_ID指的是创建的通知的ID
        startForeground(999, builder.build());
    }

    private void startTimingCapture() {

        Runnable mCaptureRunnable = new Runnable() {

            @Override
            public void run() {
                Log.i(TAG, "start capture..");
                mCaptureHandler.postDelayed(this, 1500);//每隔1s执行
                startVirtual();
                startCapture();
            }
        };
        mCaptureHandler.postDelayed(mCaptureRunnable, 10000);//延时多长时间启动定时器
    }

    Handler backgroundHandler;

    private Handler getBackgroundHandler() {
        if (backgroundHandler == null) {
            HandlerThread backgroundThread =
                    new HandlerThread("catwindow", android.os.Process
                            .THREAD_PRIORITY_BACKGROUND);
            backgroundThread.start();
            backgroundHandler = new Handler(backgroundThread.getLooper());
        }
        return backgroundHandler;
    }

    //截屏
    private void startCapture() {
        mImageReader.setOnImageAvailableListener(reader -> {
            Image image = mImageReader.acquireLatestImage();
            if (image == null) {
                Log.e(TAG, "ImageReader is null");
                return;
            }
            int width = image.getWidth();
            int height = image.getHeight();
            final Image.Plane[] planes = image.getPlanes();
            final ByteBuffer buffer = planes[0].getBuffer();
            int pixelStride = planes[0].getPixelStride();
            int rowStride = planes[0].getRowStride();
            int rowPadding = rowStride - pixelStride * width;
            Bitmap bitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888);
            bitmap.copyPixelsFromBuffer(buffer);
            bitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height);
            image.close();
            Mat src = new Mat();
            Utils.bitmapToMat(bitmap, src);
            Imgproc.cvtColor(src, src, Imgproc.COLOR_RGBA2BGRA);
            try {
                src = new Mat(src, DeviceNumericalValue.THRESHOLD_ACTUAL_AREA_1_2_3);
                Mat mat_2_3 = new Mat(src, DeviceNumericalValue.THRESHOLD_ACTUAL_AREA_2_3);
                Mat mat_1 = new Mat(src, DeviceNumericalValue.THRESHOLD_ACTUAL_AREA_1);
                String fileName = "" + System.currentTimeMillis();
                PokerCv.identify(mat_1, 1);
                PokerCv.identify(mat_2_3, 2 | 3);
                PokerCountView.updateCount(PokerManager.getInstance().getAllPokerInfo());
                PokerCountView.updateSequence(PokerManager.getInstance().getPokerSequence());
                if (IS_SAVE_FILE) {
                    try {
                        File fileImage = new File(Environment.getExternalStorageDirectory().getPath() + "/opencv-test/" + fileName + ".png");
                        if (!fileImage.exists()) {
                            fileImage.createNewFile();
                        }
                        FileOutputStream out = new FileOutputStream(fileImage);
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                        out.flush();
                        out.close();
                        Intent media = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                        Uri contentUri = Uri.fromFile(fileImage);
                        media.setData(contentUri);
                        this.sendBroadcast(media);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
                if (IS_SAVE_FILE) {
                    Imgcodecs.imwrite(Environment.getExternalStorageDirectory().getPath() + "/opencv-test/mat_" + System.currentTimeMillis() + ".png", src);
                }
            } finally {
                mImageReader.setOnImageAvailableListener(null, null);
            }
//            //此处做poker识别,释放
        }, getBackgroundHandler());

    }


    private void createVirtualEnvironment() {
        mMediaProjectionManager = (MediaProjectionManager) getApplication().getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        WindowManager mWindowManager = (WindowManager) getApplication().getSystemService(Context.WINDOW_SERVICE);
        windowWidth = mWindowManager.getDefaultDisplay().getWidth();
        windowHeight = mWindowManager.getDefaultDisplay().getHeight();
        DisplayMetrics metrics = new DisplayMetrics();
        mWindowManager.getDefaultDisplay().getMetrics(metrics);
        mScreenDensity = metrics.densityDpi;
        mImageReader = ImageReader.newInstance(windowWidth, windowHeight, 0x1, 2);
    }

    //创建虚拟显示器
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public void startVirtual() {
        if (mMediaProjection == null) {
            setUpMediaProjection();
            virtualDisplay();
        }
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public void setUpMediaProjection() {
        Intent mResultData = ((PokerRecordApplication) getApplication()).getIntent();
        int mResultCode = ((PokerRecordApplication) getApplication()).getResult();
        mMediaProjectionManager = ((PokerRecordApplication) getApplication()).getMediaProjectionManager();
        mMediaProjection = mMediaProjectionManager.getMediaProjection(mResultCode, mResultData);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private void virtualDisplay() {
        mVirtualDisplay = mMediaProjection.createVirtualDisplay("screen-mirror",
                windowWidth, windowHeight, mScreenDensity, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                mImageReader.getSurface(), null, null);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private void tearDownMediaProjection() {
        if (mMediaProjection != null) {
            mMediaProjection.stop();
            mMediaProjection = null;
        }
    }

    private void stopVirtual() {
        if (mVirtualDisplay == null) {
            return;
        }
        mVirtualDisplay.release();
        mVirtualDisplay = null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        tearDownMediaProjection();
        stopVirtual();
    }

}

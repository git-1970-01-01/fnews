package com.mm.poker.record.manager;

import android.os.Build;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import com.mm.poker.record.knn.KnnUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PokerManager {

    private static final PokerManager ourInstance = new PokerManager();


    public static final String PATH = Environment.getExternalStorageDirectory().getPath() + "/opencv-test/";

    private List<PokerInfo> allPokerInfo = new ArrayList<>();

    private Map<Integer, List<String>> pokerSequenceList = new HashMap<>();

    public static PokerManager getInstance() {
        return ourInstance;
    }


    private PokerManager() {
        KnnUtils.init();
        List<String> suit = Arrays.asList("MH", "HX", "HT", "FK");
        List<String> nums = Arrays.asList("A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K");
        for (int i = 0; i < suit.size(); i++) {
            for (int i1 = 0; i1 < nums.size(); i1++) {
                allPokerInfo.add(new PokerInfo(nums.get(i1), suit.get(i)));
            }
        }
    }

    private void resetAllPokerInfo() {
        allPokerInfo.clear();
        List<String> suit = Arrays.asList("MH", "HX", "HT", "FK");
        List<String> nums = Arrays.asList("A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K");
        for (int i = 0; i < suit.size(); i++) {
            for (int i1 = 0; i1 < nums.size(); i1++) {
                allPokerInfo.add(new PokerInfo(nums.get(i1), suit.get(i)));
            }
        }
    }


    @RequiresApi(api = Build.VERSION_CODES.N)
    public void record(PokerInfo info) {
        allPokerInfo.removeIf(info::equals);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public String record(String num, String suit, int are) {
        PokerInfo p = new PokerInfo(num, suit);
        if (allPokerInfo.contains(p)) {
            Log.i("poker_record", p.get());
            allPokerInfo.remove(p);
            return p.getNum() + "_" + p.getSuit();
        }
        return null;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void record(int area, String seq) {
        if (!TextUtils.isEmpty(seq) && area != 1) {
            //
            List<String> sequenceList = pokerSequenceList.get(area);
            if (sequenceList == null) {
                sequenceList = new ArrayList<>();
                sequenceList.add(seq);
            } else {
                if (sequenceList.size() > 0) {
                    //获取最后一次记录的值
                    String lastRecord = sequenceList.get(sequenceList.size() - 1);
                    Log.i("poker_sequence", "lastRecord:" + lastRecord);
                    Log.i("poker_sequence", "seq:" + seq);
                    if (!seq.equals(lastRecord)) {
                        if (Arrays.stream(lastRecord.split("&")).anyMatch(seq::contains)) {
                            sequenceList.remove(lastRecord);
                        }
                        sequenceList.add(seq);
                    }
                }
            }
            pokerSequenceList.put(area, sequenceList);
        }
    }


    public List<PokerInfo> getAllPokerInfo() {
        return allPokerInfo;
    }

    public void reset() {
        resetAllPokerInfo();
        pokerSequenceList.clear();
    }

    public Map<Integer, List<String>> getPokerSequence() {
        return pokerSequenceList;
    }

    public class PokerInfo {
        String realNum;
        String realSuit;


        public PokerInfo(String realNum, String realSuit) {
            this.realNum = realNum;
            this.realSuit = realSuit;
        }

        @Override
        public boolean equals(@Nullable Object obj) {
            if (obj instanceof PokerInfo) {
                return ((PokerInfo) obj).get().equals(this.get());
            }
            return super.equals(obj);
        }

        @Override
        public int hashCode() {
            return get().hashCode();
        }


        public String getNum() {
            return this.realNum;
        }

        public String get() {
            return this.realSuit + this.realNum;
        }


        public String getSuit() {
            return realSuit;
        }
    }


}

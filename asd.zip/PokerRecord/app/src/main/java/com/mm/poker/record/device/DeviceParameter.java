package com.mm.poker.record.device;

import android.content.Context;
import android.graphics.Point;
import android.view.WindowManager;

//根據屏幕分辨率的各種參數
public class DeviceParameter {

    public static int[] CUT_REAL_CONTENT_AREA = new int[4];
    public static int[] CUT_OWN_IDENTIFY_AREA = new int[4];
    public static int[] CUT_PUBLIC_IDENTIFY_AREA = new int[4];
    public static int RECT_POKER_HEIGHT = -1;
    public static int RECT_POKER_WIDTH = -1;
    public static int RECT_POKER_IDENTIFY_AREA = -1;
    public static int RECT_LAST_POKER_EXTRA_AREA = -1;
    public static double RECT_WHITE_NOISES_WIDTH = -1;
    public static double RECT_WHITE_NOISES_HEIGHT = -1;
    public static double SIZE_ERODE_WIDTH = 0.0d;
    public static double SIZE_ERODE_HEIGHT = 0.0d;
    //扑克区域阈值
    public static double RECT_POKER_AREA_THRESHOLD = 0.0d;
    public static double RECT_POKER_HEIGHT_THRESHOLD = 0.0d;

    public static double RECT_POKER_PUBLIC_MIN_AREA_THRESHOLD = 0.0d;
    public static double RECT_POKER_PUBLIC_MAX_AREA_THRESHOLD = 0.0d;
    public static double RECT_POKER_PUBLIC_HEIGHT_THRESHOLD = 0.0d;
    public static int[] CUT_SCORE_AREA = new int[4];

    public static void init(Context context) {
        //TODO 此處做賦值，根據屏幕分辨率
        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Point point = new Point();
        windowManager.getDefaultDisplay().getRealSize(point);
        int width = point.x;
        //參考係數為 1080 * 1920
        double rate = 1080D / width;
        RECT_POKER_HEIGHT = (int) (88 * rate);
        CUT_REAL_CONTENT_AREA = new int[]{0, (int) (746 * rate), width, (int) (540 * rate)};
        CUT_OWN_IDENTIFY_AREA = new int[]{0, (int) (335 * rate), (int) (1080 * rate), RECT_POKER_HEIGHT};
        RECT_LAST_POKER_EXTRA_AREA = (int) (70 * rate);
        RECT_WHITE_NOISES_WIDTH = (int) (7.5 * rate);
        RECT_WHITE_NOISES_HEIGHT = (int) (7.5 * rate);
        SIZE_ERODE_WIDTH = 5d * rate;
        SIZE_ERODE_HEIGHT = 15d * rate;
        RECT_POKER_AREA_THRESHOLD = 300d * rate;
        RECT_POKER_HEIGHT_THRESHOLD = 27d * rate;
        CUT_PUBLIC_IDENTIFY_AREA = new int[]{280, 163, 520 - 30, 52};
        CUT_SCORE_AREA = new int[]{66, 316, 85, 21};
        RECT_POKER_PUBLIC_MIN_AREA_THRESHOLD = 64;
        RECT_POKER_PUBLIC_HEIGHT_THRESHOLD = 30;
        RECT_POKER_PUBLIC_MAX_AREA_THRESHOLD = 600;
        RECT_POKER_WIDTH = (int) (rate * 41);
        RECT_POKER_IDENTIFY_AREA = (int) (rate * 70);
    }


    public static void init() {
        
    }

}
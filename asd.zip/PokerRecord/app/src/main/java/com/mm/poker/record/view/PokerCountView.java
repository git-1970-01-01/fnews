package com.mm.poker.record.view;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.widget.TextView;

import com.lzf.easyfloat.EasyFloat;
import com.lzf.easyfloat.enums.ShowPattern;
import com.lzf.easyfloat.enums.SidePattern;
import com.mm.poker.record.R;
import com.mm.poker.record.manager.PokerManager;
import com.mm.poker.record.service.PokerService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

public class PokerCountView {

    private static final String POKER_FLOAT_VIEW_TAG = "poker_float_view_tag";

    private static Map<String, TextView> refPokerViews = new HashMap<>();

    public static void show(Activity refActivity) {
        EasyFloat.with(refActivity).setLayout(R.layout.poker_layout, view -> {
        }).setTag(POKER_FLOAT_VIEW_TAG).setShowPattern(ShowPattern.ALL_TIME).setDragEnable(false).setGravity(Gravity.CENTER_HORIZONTAL, 0, 0)
                .invokeView(view -> {
//            refPokerViews.put("JOKER", view.findViewById(R.id.poker_joker));
                    refPokerViews.put("A", view.findViewById(R.id.poker_A));
                    refPokerViews.put("2", view.findViewById(R.id.poker_2));
                    refPokerViews.put("3", view.findViewById(R.id.poker_3));
                    refPokerViews.put("4", view.findViewById(R.id.poker_4));
                    refPokerViews.put("5", view.findViewById(R.id.poker_5));
                    refPokerViews.put("6", view.findViewById(R.id.poker_6));
                    refPokerViews.put("7", view.findViewById(R.id.poker_7));
                    refPokerViews.put("8", view.findViewById(R.id.poker_8));
                    refPokerViews.put("9", view.findViewById(R.id.poker_9));
                    refPokerViews.put("10", view.findViewById(R.id.poker_10));
                    refPokerViews.put("J", view.findViewById(R.id.poker_J));
                    refPokerViews.put("Q", view.findViewById(R.id.poker_Q));
                    refPokerViews.put("K", view.findViewById(R.id.poker_K));
                    refPokerViews.put("AREA2", view.findViewById(R.id.area2Tv));
                    refPokerViews.put("AREA3", view.findViewById(R.id.area3Tv));
                    view.findViewById(R.id.reset).setOnClickListener(v -> {
                        PokerManager.getInstance().reset();
                        refPokerViews.get("AREA2").setText("");
                        refPokerViews.get("AREA3").setText("");
                    });
//                    view.findViewById(R.id.capture).setOnClickListener(v -> {
//                        testTextView();
//                    });
                }).show();

    }

    public static void updateCount(List<PokerManager.PokerInfo> pokerInfos) {
        Map<String, Long> collect = pokerInfos.stream().collect(Collectors.groupingBy(PokerManager.PokerInfo::getNum, Collectors.counting()));
        List<String> temp = new ArrayList<>(Arrays.asList("A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"));
        List<String> tempList = temp.stream().filter(s -> collect.get(s) == null).collect(Collectors.toList());
        tempList.forEach(s -> collect.put(s, 0L));
        collect.forEach((k, v) -> {
            TextView tv = refPokerViews.get(k);
            if (v.intValue() != Integer.parseInt(tv.getText().toString())) {
                tv.setText(v + "");
            }
        });
    }

    public static String toDBC(String input) {
        char[] c = input.toCharArray();
        for (int i = 0; i < c.length; i++) {
            if (c[i] == 12288) {// 全角空格为12288，半角空格为32
                c[i] = (char) 32;
                continue;
            }
            if (c[i] > 65280 && c[i] < 65375)// 其他字符半角(33-126)与全角(65281-65374)的对应关系是：均相差65248
                c[i] = (char) (c[i] - 65248);
        }
        return new String(c);
    }

    public static void testTextView() {
        PokerSequenceTextView tv2 = (PokerSequenceTextView) refPokerViews.get("AREA2");
        TextView tv3 = refPokerViews.get("AREA3");
        tv2.setText(toDBC("4,A,7777,5,8,2,9,10,JJJJ,66"));
        tv3.setText(toDBC("4,A,J10987,3,9,5554,KK,6"));
    }

    public static void updateSequence(Map<Integer, List<String>> map) {
        map.entrySet().forEach(integerStringBuilderEntry -> {
            TextView tv = refPokerViews.get("AREA" + integerStringBuilderEntry.getKey());
            if (tv != null) {
                if (!Objects.equals(tv.getText().toString(), integerStringBuilderEntry.getValue())) {
                    String result = TextUtils.join(",", integerStringBuilderEntry.getValue()).replaceAll("_FK&", "").replaceAll("_HT&", "").replaceAll("_HX&", "").replaceAll("_MH&", "");
                    Log.i("poker_sequence_result", "result:" + result);
                    tv.setText(result);
                }
            }
        });
    }

}

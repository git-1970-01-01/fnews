package com.mm.poker.record.opencv;

import android.annotation.SuppressLint;
import android.os.Build;

import androidx.annotation.RequiresApi;

import com.mm.poker.record.device.DeviceNumericalValue;
import com.mm.poker.record.device.DeviceParameter;
import com.mm.poker.record.knn.KnnUtils;
import com.mm.poker.record.manager.PokerManager;
import com.mm.poker.record.service.PokerService;

import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.MatOfPoint2f;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 *
 */
public class PokerCv {

    private static final String PATH = "/storage/emulated/0/opencv-test/";


    public static Rect matOfPointToRect(MatOfPoint matOfPoint) {
        MatOfPoint2f approxCurve = new MatOfPoint2f();
        Imgproc.approxPolyDP(new MatOfPoint2f(matOfPoint.toArray()), approxCurve, 1, true);
        return Imgproc.boundingRect(approxCurve);
    }


    public static List<MatOfPoint> findContours(Mat mat, int mode, int method) {
        //在OpenCV中，查找轮廓就像是在黑色背景中找白色物体，要记住要找的物体应该是白色而背景应该是黑色
        Mat dst = new Mat();
        Core.bitwise_not(mat, dst);
        List<MatOfPoint> list = new ArrayList<>();
        Imgproc.findContours(dst, list, new Mat(), mode, method);
        return list;
    }


    public static void identify(Mat mat, int area) {
        Imgproc.cvtColor(mat, mat, Imgproc.COLOR_RGB2GRAY);
        Imgproc.threshold(mat, mat, 180, 255, Imgproc.THRESH_BINARY);
        Mat threshold = new Mat();
        mat.copyTo(threshold);
        if (area == (2 | 3)) {
            //TODO 此处需要优化
            for (int i = 0; i < mat.cols(); i++) {
                double v = mat.get(0, i)[0];
                if (v == 0 && i < 240) {
                    final int startPix = i;
                    double sum = IntStream.rangeClosed(1, 23).mapToDouble(value -> mat.get(0, startPix + value)[0]).sum();
                    if (sum == 0) {
                        IntStream.rangeClosed(0, 4).forEach(row -> IntStream.rangeClosed(0, 24).forEach(value -> mat.put(row, startPix + value + 1, 255, 255, 255)));
                        break;
                    }
                }
            }
            for (int i = mat.cols() - 1; i > 0; i--) {
                double v = mat.get(0, i)[0];
                if (v == 255) {
                    final int i1 = i;
                    IntStream.rangeClosed(0, mat.cols() - 1 - i).forEach(v1 -> {
                        IntStream.rangeClosed(i1 + 1, mat.cols()).forEach(value -> mat.put(v1, value, 255, 255, 255));
                    });
                    break;
                }
            }
        }
        List<MatOfPoint> _step1 = findContours(mat, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE);
        //TODO 去除雜質
        List<Rect> rectList = _step1.stream().filter(matOfPoint -> {
            Rect r = matOfPointToRect(matOfPoint);
            return (r.width >= DeviceNumericalValue.getMinWidth(area) && r.width < DeviceNumericalValue.getMaxWidth(area)) || (r.height >= DeviceNumericalValue.getMinHeight(area) && r.height < DeviceNumericalValue.getMaxHeight(area));
        }).map(PokerCv::matOfPointToRect).collect(Collectors.toList());
        List<Rect> mayNumRect = rectList.stream().filter(rect -> rect.y < DeviceNumericalValue.getStartY(area)).collect(Collectors.toList());
        List<Rect> maySuitRect = rectList.stream().filter(rect -> rect.y > DeviceNumericalValue.getStartY(area)).collect(Collectors.toList());
        if (mayNumRect.size() == 0) {
            return;
        }
        @SuppressLint("UseSparseArrays") Map<Integer, List<Rect>> mapAreaRect = new HashMap<>();
        mayNumRect.sort((o1, o2) -> o1.x - o2.x);
        maySuitRect.sort((o1, o2) -> o1.x - o2.x);
        if (area == (2 | 3)) {
            mapAreaRect = splitArea(mayNumRect);
        } else {
            mapAreaRect.put(1, mayNumRect);
        }
        mapAreaRect.entrySet().forEach(map -> {
            Integer key = map.getKey();
            List<Rect> value = map.getValue();
            StringBuilder sequence = new StringBuilder();
            for (int i = 0; i < value.size(); i++) {
                List<Rect> list = new ArrayList<>();
                Rect rect = value.get(i);
                list.add(rect);
                n(list, maySuitRect);
                if (list.size() == 2) {
                    list.sort((o1, o2) -> o2.height - o1.height);
                    Mat num = new Mat(mat, list.get(0));
                    Mat suit = new Mat(mat, list.get(1));
                    Imgproc.resize(num, num, new Size(32, 32));
                    Imgproc.resize(suit, suit, new Size(32, 32));
                    String numResult = KnnUtils.classify(getBytes(num), 0, false);
                    String suitResult = KnnUtils.classify(getBytes(suit), 1, false);
                    if (Objects.equals(numResult, KnnUtils.IDENTIFY_ERROR) && !Objects.equals(suitResult, KnnUtils.IDENTIFY_ERROR)) {
                        numResult = KnnUtils.classify(getBytes(num), 0, true);
                    }
                    if (!Objects.equals(numResult, KnnUtils.IDENTIFY_ERROR) && !Objects.equals(suitResult, KnnUtils.IDENTIFY_ERROR)) {
                        PokerManager.getInstance().record(numResult, suitResult, area);
                        sequence.append(numResult + "_" + suitResult + "&");
                    } else {
                        //识别错误，人工调整保存至训练集
                        if (PokerService.IS_SAVE_FILE) {
                            String name = PATH + System.currentTimeMillis() + new Random().nextInt(10000) + "";
                            Imgcodecs.imwrite(name + "_complete.png", suit);
                            Imgcodecs.imwrite(name + "_num.png", num);
                            Imgcodecs.imwrite(name + "_suit.png", suit);
                        }
                    }
                }
            }
            PokerManager.getInstance().record(key, sequence.toString());
        });
    }

    //分割公共區域，記錄出牌
    private static Map<Integer, List<Rect>> splitArea(List<Rect> list) {
        Rect flagRect = list.get(0);
        Map<Integer, List<Rect>> mapArea = new HashMap<>();
        List<Rect> listArea2 = new ArrayList<>();
        List<Rect> listArea3 = new ArrayList<>();
        int area = list.get(0).x < 10 ? 2 : 3;
        if (area == 2) {
            listArea2.add(flagRect);
        } else {
            listArea3.add(flagRect);
        }
        for (int i = 1; i < list.size(); i++) {
            Rect rect = list.get(i);
            if (Math.abs(flagRect.x + flagRect.width - rect.x) < 30) {
                if (area == 2) {
                    listArea2.add(rect);
                } else {
                    listArea3.add(rect);
                }
            } else {
                area = 3;
                listArea3.add(rect);
            }
            flagRect = rect;
        }
        mapArea.put(2, listArea2);
        mapArea.put(3, listArea3);
        return mapArea;
    }

    private static byte[] getBytes(Mat mat) {
        byte[] bytes = new byte[32 * 32];
        for (int index = 0; index < mat.rows(); index++) {
            for (int i = 0; i < mat.cols(); i++) {
                byte v = mat.get(index, i)[0] == 255 ? (byte) 0 : (byte) 1;
                bytes[32 * index + i] = v;
            }
        }
        return bytes;
    }

    //模型 [*,*,*,*,*]
    private static void n(List<Rect> f, List<Rect> maySuitRect) {
        for (int i = 0; i < maySuitRect.size(); i++) {
            Rect r = maySuitRect.get(i);
            if (r.y - f.get(f.size() - 1).height - f.get(f.size() - 1).y < 10 && Math.abs(r.x - f.get(f.size() - 1).x) < 5) {
                f.add(r);
                maySuitRect.remove(i);
                n(f, maySuitRect);
                break;
            }
        }
    }
}

package com.mm.poker.record.opencv;

import android.annotation.SuppressLint;
import android.os.Build;
import android.os.Environment;
import android.telephony.CellSignalStrengthGsm;

import androidx.annotation.RequiresApi;

import com.mm.poker.record.device.DeviceNumericalValue;
import com.mm.poker.record.device.DeviceParameter;
import com.mm.poker.record.knn.KnnUtils;
import com.mm.poker.record.manager.PokerManager;
import com.mm.poker.record.service.PokerService;

import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.MatOfPoint2f;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 *
 */
public class PokerCv {

    private static final String PATH = "/storage/emulated/0/opencv-test/";

    private static final double MIN_RATE = 0.66667D;

    private static final double MAX_RATE = 1.5D;

    private static Rect THRESHOLD_ACTUAL_AREA_1_2_3 = null;

    public static Rect THRESHOLD_ACTUAL_AREA_2_3 = null;

    public static Rect matOfPointToRect(MatOfPoint matOfPoint) {
        MatOfPoint2f approxCurve = new MatOfPoint2f();
        Imgproc.approxPolyDP(new MatOfPoint2f(matOfPoint.toArray()), approxCurve, 1, true);
        return Imgproc.boundingRect(approxCurve);
    }


    public static List<MatOfPoint> findContours(Mat mat, int mode, int method) {
        //在OpenCV中，查找轮廓就像是在黑色背景中找白色物体，要记住要找的物体应该是白色而背景应该是黑色
        Mat dst = new Mat();
        Core.bitwise_not(mat, dst);
        List<MatOfPoint> list = new ArrayList<>();
        Imgproc.findContours(dst, list, new Mat(), mode, method);
        return list;
    }


    public static void identify(Mat mat, int area) {
        Imgproc.cvtColor(mat, mat, Imgproc.COLOR_RGB2GRAY);
        Imgproc.threshold(mat, mat, 180, 255, Imgproc.THRESH_BINARY);
        Mat threshold = new Mat();
        mat.copyTo(threshold);
        if (area == (2 | 3)) {
            int sI = 0, sJ = 0;
            iA:
            for (int i = 0; i < mat.rows() - 20; i++) {
                for (int j = 0; j < mat.cols() - 20; j++) {
                    double v = mat.get(i, j)[0];
                    if (v == 0) {
                        boolean isFind = true;
                        for (int k = 0; k < 20; k++) {
                            double v1 = mat.get(i + k, j + k)[0];
                            double v2 = mat.get(i + k + 1, j + k)[0];
                            if (v1 == 0 && v2 == 255) {
                            } else {
                                isFind = false;
                                break;
                            }
                        }
                        if (isFind) {
                            sI = i;
                            sJ = j;
                            break iA;
                        }
                    }
                }
            }
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < 20; j++) {
                    mat.put(sI + i, sJ + i + j, 255);
                }
            }
        }
        Imgcodecs.imwrite(Environment.getExternalStorageDirectory().getPath() + "/Download/mat.png", mat);
        List<MatOfPoint> _step1 = findContours(mat, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE);
        //TODO 去除雜質
        List<Rect> rectList = _step1.stream().filter(matOfPoint -> {
            Rect r = matOfPointToRect(matOfPoint);
            return (r.width >= DeviceNumericalValue.getMinWidth(area) && r.width < DeviceNumericalValue.getMaxWidth(area)) || (r.height >= DeviceNumericalValue.getMinHeight(area) && r.height < DeviceNumericalValue.getMaxHeight(area));
        }).map(PokerCv::matOfPointToRect).collect(Collectors.toList());
        List<Rect> mayNumRect = rectList.stream().filter(rect -> rect.y < DeviceNumericalValue.getStartY(area)).collect(Collectors.toList());
        List<Rect> maySuitRect = rectList.stream().filter(rect -> rect.y > DeviceNumericalValue.getStartY(area)).collect(Collectors.toList());
        if (mayNumRect.size() == 0) {
            return;
        }
        @SuppressLint("UseSparseArrays") Map<Integer, List<Rect>> mapAreaRect = new HashMap<>();
        mayNumRect.sort((o1, o2) -> o1.x - o2.x);
        maySuitRect.sort((o1, o2) -> o1.x - o2.x);
        if (area == (2 | 3)) {
            mapAreaRect = splitArea(mayNumRect);
        } else {
            mapAreaRect.put(1, mayNumRect);
        }
        mapAreaRect.entrySet().forEach(map -> {
            Integer key = map.getKey();
            List<Rect> value = map.getValue();
            StringBuilder sequence = new StringBuilder();
            for (int i = 0; i < value.size(); i++) {
                List<Rect> list = new ArrayList<>();
                Rect rect = value.get(i);
                list.add(rect);
                n(list, maySuitRect);
                if (list.size() == 2) {
                    list.sort((o1, o2) -> o2.height - o1.height);
                    Mat num = new Mat(mat, list.get(0));
                    Mat suit = new Mat(mat, list.get(1));
                    Imgproc.resize(num, num, new Size(32, 32));
                    Imgproc.resize(suit, suit, new Size(32, 32));
                    String numResult = KnnUtils.classify(getBytes(num), 0, false);
                    String suitResult = KnnUtils.classify(getBytes(suit), 1, false);
                    if (Objects.equals(numResult, KnnUtils.IDENTIFY_ERROR) && !Objects.equals(suitResult, KnnUtils.IDENTIFY_ERROR)) {
                        numResult = KnnUtils.classify(getBytes(num), 0, true);
                    }
                    if (!Objects.equals(numResult, KnnUtils.IDENTIFY_ERROR) && !Objects.equals(suitResult, KnnUtils.IDENTIFY_ERROR)) {
                        PokerManager.getInstance().record(numResult, suitResult, area);
                        sequence.append(numResult + "_" + suitResult + "&");
                    } else {
                        //识别错误，人工调整保存至训练集
                        if (PokerService.IS_SAVE_FILE) {
                            String name = PATH + System.currentTimeMillis() + new Random().nextInt(10000) + "";
                            Imgcodecs.imwrite(name + "_complete.png", suit);
                            Imgcodecs.imwrite(name + "_num.png", num);
                            Imgcodecs.imwrite(name + "_suit.png", suit);
                        }
                    }
                }
            }
            PokerManager.getInstance().record(key, sequence.toString());
        });
    }

    //分割公共區域，記錄出牌
    private static Map<Integer, List<Rect>> splitArea(List<Rect> list) {
        Rect flagRect = list.get(0);
        Map<Integer, List<Rect>> mapArea = new HashMap<>();
        List<Rect> listArea2 = new ArrayList<>();
        List<Rect> listArea3 = new ArrayList<>();
        int area = list.get(0).x < 10 ? 2 : 3;
        if (area == 2) {
            listArea2.add(flagRect);
        } else {
            listArea3.add(flagRect);
        }
        for (int i = 1; i < list.size(); i++) {
            Rect rect = list.get(i);
            if (Math.abs(flagRect.x + flagRect.width - rect.x) < 30) {
                if (area == 2) {
                    listArea2.add(rect);
                } else {
                    listArea3.add(rect);
                }
            } else {
                area = 3;
                listArea3.add(rect);
            }
            flagRect = rect;
        }
        mapArea.put(2, listArea2);
        mapArea.put(3, listArea3);
        return mapArea;
    }

    private static byte[] getBytes(Mat mat) {
        byte[] bytes = new byte[32 * 32];
        for (int index = 0; index < mat.rows(); index++) {
            for (int i = 0; i < mat.cols(); i++) {
                byte v = mat.get(index, i)[0] == 255 ? (byte) 0 : (byte) 1;
                bytes[32 * index + i] = v;
            }
        }
        return bytes;
    }

    //模型 [*,*,*,*,*]
    private static void n(List<Rect> f, List<Rect> maySuitRect) {
        for (int i = 0; i < maySuitRect.size(); i++) {
            Rect r = maySuitRect.get(i);
            if (r.y - f.get(f.size() - 1).height - f.get(f.size() - 1).y < 10 && Math.abs(r.x - f.get(f.size() - 1).x) < 5) {
                f.add(r);
                maySuitRect.remove(i);
                n(f, maySuitRect);
                break;
            }
        }
    }

    //初始化參數
    public static void init(Mat mat) {
        Mat tmp = new Mat();
        mat.copyTo(tmp);
        int y = IntStream.range(0, mat.rows()).filter(value -> mat.get(value, 0)[0] != 0).findFirst().getAsInt();
        int height = IntStream.range(y, mat.rows()).filter(value -> mat.get(value, 0)[0] == 0).findFirst().getAsInt() - y;
        int x = 0;
        int width = mat.cols();
        THRESHOLD_ACTUAL_AREA_1_2_3 = new Rect(x, y, width, height);
        tmp = new Mat(tmp, THRESHOLD_ACTUAL_AREA_1_2_3);
        Imgproc.cvtColor(tmp, tmp, Imgproc.COLOR_RGB2GRAY);
        Imgproc.threshold(tmp, tmp, 180, 255, Imgproc.THRESH_BINARY);
        //
        List<MatOfPoint> allMatOfPoint4Filter = findContours(tmp, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
        //去除懸浮窗頂部的區域0,並限定大小
        allMatOfPoint4Filter.removeIf(matOfPoint -> matOfPointToRect(matOfPoint).y < 100 || matOfPointToRect(matOfPoint).area() < 200);
        int _2_3_y = -1;
        int _2_3_height = -1;
        int _1_y = -1;
        int _1_height = -1;
        List<Double> _2_3_area_filter = new ArrayList<>();
        List<Integer> _2_3_width_filter = new ArrayList<>();
        List<Double> _1_area_filter = new ArrayList<>();
        List<Integer> _1_width_filter = new ArrayList<>();
        for (int i = 0; i < allMatOfPoint4Filter.size(); i++) {
            Rect rect = matOfPointToRect(allMatOfPoint4Filter.get(i));
            Mat knnMat = new Mat(tmp, rect);
            Imgproc.resize(knnMat, knnMat, new Size(32, 32));
            String numClassify = KnnUtils.classify(getBytes(knnMat), 0, false);
            String suitClassify = KnnUtils.classify(getBytes(knnMat), 1, false);
            System.err.println(numClassify + "," + suitClassify);
            if (!Objects.equals(numClassify, KnnUtils.IDENTIFY_ERROR) || !Objects.equals(suitClassify, KnnUtils.IDENTIFY_ERROR)) {
                if (Arrays.asList(KnnUtils.POKER_NUM).contains(numClassify)) {
                    //找到出牌区,10个像素内找顶边
                    for (int j = rect.y - 1; j > rect.y - 10; j--) {
                        if (tmp.get(j, rect.x)[0] == 0) {
                            if (rect.y < height / 2 && _2_3_y == -1) {
                                _2_3_y = j + 1;
                                _2_3_height = rect.y - j + rect.height * 2;
                            } else if (_1_y == -1) {
                                _1_y = j + 1;
                                _1_height = rect.y - j + rect.height * 2;
                            }
                            break;
                        }
                    }
                } else if (Arrays.asList(KnnUtils.POKER_SUIT).contains(suitClassify)) {
                    if (rect.y < height / 2) {
                        _2_3_area_filter.add(rect.area());
                        _2_3_width_filter.add(rect.width);
                        Imgcodecs.imwrite(Environment.getExternalStorageDirectory().getPath() + "/Download/_" + suitClassify + "_" + rect.width + "_" + System.currentTimeMillis() + ".png", new Mat(tmp, matOfPointToRect(allMatOfPoint4Filter.get(i))));
                    } else {
                        _1_area_filter.add(rect.area());
                        _1_width_filter.add(rect.width);
                    }
                }
            }
        }

        System.err.println("===============<" + _2_3_width_filter.size());
        tmp = new Mat(tmp, new Rect(0, _1_y, 1080, _1_height));
        double minArea = _2_3_area_filter.stream().min(Comparator.comparing(Double::doubleValue)).get() * 2 / 3;
        double maxWidth = _2_3_width_filter.stream().max(Comparator.comparing(Integer::intValue)).get() * 1.5;
        System.err.println("===============<" + minArea + "," + maxWidth);
        Imgcodecs.imwrite(Environment.getExternalStorageDirectory().getPath() + "/Download/tmp.png", tmp);

    }


}

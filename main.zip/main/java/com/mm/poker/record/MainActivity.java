package com.mm.poker.record;

import android.animation.Keyframe;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.lzf.easyfloat.permission.PermissionUtils;
import com.mm.poker.record.device.DeviceNumericalValue;
import com.mm.poker.record.knn.KnnUtils;
import com.mm.poker.record.manager.PokerManager;
import com.mm.poker.record.opencv.PokerCv;
import com.mm.poker.record.service.PokerService;
import com.mm.poker.record.view.PokerCountView;

import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.Mat;
import org.opencv.imgproc.Imgproc;

import java.io.FileInputStream;
import java.util.Random;
import java.util.function.Consumer;


public class MainActivity extends AppCompatActivity {


    private int REQUEST_MEDIA_PROJECTION = 1;

    private MediaProjectionManager mMediaProjectionManager;

    private static final int INIT_OPENCV_MESSAGE = 3;

    private static final int CHECK_PERMISSION_MESSAGE = 4;

    private boolean _float_permission = false;

    private Handler mAsyncHandler;

    private TextSwitcher mOpenCvTextSwitcher, mCanDrawOverlaysTextSwitcher, mCanDrawOverlaysHintTextSwitcher, mStartQqGameHlddzTextSwitcher;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Window window = getWindow();
        View decorView = window.getDecorView();
        int option = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        decorView.setSystemUiVisibility(option);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(Color.TRANSPARENT);
        mMediaProjectionManager = (MediaProjectionManager)
                getApplication().
                        getSystemService(Context.MEDIA_PROJECTION_SERVICE);


        mOpenCvTextSwitcher = findViewById(R.id.open_cv_load_text);
        mCanDrawOverlaysTextSwitcher = findViewById(R.id.can_draw_overlays_text);
        mCanDrawOverlaysHintTextSwitcher = findViewById(R.id.can_draw_overlays_text_hint);
        mStartQqGameHlddzTextSwitcher = findViewById(R.id.start_qqgame_hlddz);


        addTextSwitcherAnim(mCanDrawOverlaysTextSwitcher, view -> {
            PermissionUtils.requestPermission(MainActivity.this, b -> {
                Message message = new Message();
                message.what = CHECK_PERMISSION_MESSAGE;
                message.arg1 = b ? 1 : 0;
                _float_permission = b;
                mAsyncHandler.sendMessageDelayed(message, 0);
            });
        });
        addTextSwitcherAnim(mOpenCvTextSwitcher, null);
        addTextSwitcherAnim(mCanDrawOverlaysHintTextSwitcher, 0xfff37f7f, 11, null);
        addTextSwitcherAnim(mStartQqGameHlddzTextSwitcher, view -> {
            if (_float_permission) {
                startCaptureIntent();
            } else {
                startShakeByPropertyAnim(mCanDrawOverlaysTextSwitcher, 0.9f, 1.1f, 1f, 1000);
            }
        });

        mOpenCvTextSwitcher.setCurrentText("OpenCv 框架加载中...");
        mCanDrawOverlaysTextSwitcher.setCurrentText("悬浮窗权限检测中...");
        mStartQqGameHlddzTextSwitcher.setCurrentText("启动游戏并开启记牌器");
        initHandler();
        async(() -> {
            Message message = new Message();
            message.what = INIT_OPENCV_MESSAGE;
            KnnUtils.init(this);
            message.arg1 = OpenCVLoader.initDebug() ? 1 : 0;
            mAsyncHandler.sendMessageDelayed(message, 1000 + new Random().nextInt(1000));
        });

        async(() -> {
            Message message = new Message();
            message.what = CHECK_PERMISSION_MESSAGE;
            message.arg1 = PermissionUtils.checkPermission(MainActivity.this) ? 1 : 0;
            _float_permission = PermissionUtils.checkPermission(MainActivity.this);
            mAsyncHandler.sendMessageDelayed(message, 500 + new Random().nextInt(1000));
        });


        long startTime = System.currentTimeMillis();
            FileInputStream fis = null;
            try {
                OpenCVLoader.initDebug();
                KnnUtils.init(this);
//                PokerCountView.show(this);
                // /storage/emulated/0/Download/2.png
                fis = new FileInputStream(Environment.getExternalStorageDirectory().getPath() + "/Download/1589119522619.png");
//                fis = new FileInputStream("/storage/emulated/0/Download/test1.png");
                Bitmap bitmap = BitmapFactory.decodeStream(fis);
                Mat mat = new Mat();
                Utils.bitmapToMat(bitmap, mat);
                PokerCv.init(mat);
//                Imgproc.cvtColor(mat, mat, Imgproc.COLOR_RGBA2BGRA);
//                mat = new Mat(mat, DeviceNumericalValue.THRESHOLD_ACTUAL_AREA_1_2_3);
//                mat = new Mat(mat, DeviceNumericalValue.THRESHOLD_ACTUAL_AREA_2_3);
////                mat = new Mat(mat, DeviceNumericalValue.THRESHOLD_ACTUAL_AREA_1);
//                PokerCv.identify(mat, 2 | 3);
//                PokerCv.identify(mat, 1);
                //java.io.FileNotFoundException: /storage/emulated/0/Download/s10e.png: open failed: EACCES (Permission denied)
                System.err.println(PokerManager.getInstance().getAllPokerInfo());
//                PokerCountView.updateCount(PokerManager.getInstance().getAllPokerInfo());
            } catch (Exception e) {
                e.printStackTrace();
            }

    }

    private void addTextSwitcherAnim(TextSwitcher textSwitcher, int color, int textSize, Consumer<View> consumer) {
        Animation in = AnimationUtils.loadAnimation(this, android.R.anim.fade_in);
        Animation out = AnimationUtils.loadAnimation(this, android.R.anim.fade_out);
        textSwitcher.setInAnimation(in);
        textSwitcher.setOutAnimation(out);
        textSwitcher.setFactory(() -> {
            TextView tv = new TextView(MainActivity.this);
            tv.setTextSize(textSize == -1 ? 14 : textSize);
            tv.setClickable(true);
            tv.setFocusable(true);
            tv.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            tv.setTextColor(color == -1 ? 0xff00ddff : color);
            tv.setBackgroundResource(R.drawable.text_selector);
            tv.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
            tv.setOnClickListener(v -> {
                if (consumer != null) {
                    consumer.accept(v);
                }
            });
            return tv;
        });
    }

    private void addTextSwitcherAnim(TextSwitcher textSwitcher, Consumer<View> consumer) {
        addTextSwitcherAnim(textSwitcher, 0xff00ddff, 14, consumer);
    }

    private void initHandler() {
        mAsyncHandler = new Handler(this.getMainLooper()) {
            @Override
            public void handleMessage(@NonNull Message msg) {
                switch (msg.what) {
                    case INIT_OPENCV_MESSAGE:
                        mOpenCvTextSwitcher.setText(msg.arg1 == 1 ? "OpenCv 框架加载成功" : "OpenCv 框架加载失败");
                        break;
                    case CHECK_PERMISSION_MESSAGE:
                        TextView view = (TextView) mCanDrawOverlaysTextSwitcher.getNextView();
                        view.setTextColor(msg.arg1 == 1 ? 0xff00ddff : 0xffe65e5e);
                        mCanDrawOverlaysTextSwitcher.setText(msg.arg1 == 1 ? "悬浮窗权限已开启" : "悬浮窗权限未开启,点击开启");
                        mCanDrawOverlaysHintTextSwitcher.setVisibility(msg.arg1 == 1 ? View.INVISIBLE : View.VISIBLE);
                        this.postDelayed(() -> mCanDrawOverlaysHintTextSwitcher.setCurrentText("此权限用于创建悬浮窗，以显示记牌器和记录牌序。"), 500);
                        break;
                }
            }
        };
    }

    private void async(Runnable runnable) {
        new Thread(runnable).start();
    }


    private void startCaptureIntent() {
        ((PokerRecordApplication) getApplication()).setMediaProjectionManager(mMediaProjectionManager);
        startActivityForResult(mMediaProjectionManager.createScreenCaptureIntent(), REQUEST_MEDIA_PROJECTION);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_MEDIA_PROJECTION) {
            if (resultCode != Activity.RESULT_OK) {
                return;
            } else if (data != null) {
                Toast.makeText(this, "正在启动腾讯斗地主", Toast.LENGTH_SHORT).show();
                ((PokerRecordApplication) getApplication()).setResult(resultCode);
                ((PokerRecordApplication) getApplication()).setIntent(data);
                Intent pokerIntent = new Intent(this, PokerService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                    pokerIntent.putExtra("code",resultCode);
//                    pokerIntent.putExtra("data",data);
                    startForegroundService(pokerIntent);
                } else {
                    startService(pokerIntent);
                }
//                startActivity(getPackageManager().getLaunchIntentForPackage("com.qqgame.hlddz"));
                mAsyncHandler.postDelayed(() -> {
                    PokerCountView.show(this);
                }, 5000);
            } else if (requestCode == 100) {
                if (Settings.canDrawOverlays(this)) {
                } else {
                    Toast.makeText(this, "ACTION_MANAGE_OVERLAY_PERMISSION权限已被拒绝", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private void startShakeByPropertyAnim(View view, float scaleSmall, float scaleLarge, float shakeDegrees, long duration) {
        if (view == null) {
            return;
        }
        //先变小后变大
        PropertyValuesHolder scaleXValuesHolder = PropertyValuesHolder.ofKeyframe(View.SCALE_X,
                Keyframe.ofFloat(0f, 1.0f),
                Keyframe.ofFloat(0.25f, scaleSmall),
                Keyframe.ofFloat(0.5f, scaleLarge),
                Keyframe.ofFloat(0.75f, scaleLarge),
                Keyframe.ofFloat(1.0f, 1.0f)
        );
        PropertyValuesHolder scaleYValuesHolder = PropertyValuesHolder.ofKeyframe(View.SCALE_Y,
                Keyframe.ofFloat(0f, 1.0f),
                Keyframe.ofFloat(0.25f, scaleSmall),
                Keyframe.ofFloat(0.5f, scaleLarge),
                Keyframe.ofFloat(0.75f, scaleLarge),
                Keyframe.ofFloat(1.0f, 1.0f)
        );

        //先往左再往右
        PropertyValuesHolder rotateValuesHolder = PropertyValuesHolder.ofKeyframe(View.ROTATION,
                Keyframe.ofFloat(0f, 0f),
                Keyframe.ofFloat(0.1f, -shakeDegrees),
                Keyframe.ofFloat(0.2f, shakeDegrees),
                Keyframe.ofFloat(0.3f, -shakeDegrees),
                Keyframe.ofFloat(0.4f, shakeDegrees),
                Keyframe.ofFloat(0.5f, -shakeDegrees),
                Keyframe.ofFloat(0.6f, shakeDegrees),
                Keyframe.ofFloat(0.7f, -shakeDegrees),
                Keyframe.ofFloat(0.8f, shakeDegrees),
                Keyframe.ofFloat(0.9f, -shakeDegrees),
                Keyframe.ofFloat(1.0f, 0f)
        );

        ObjectAnimator objectAnimator = ObjectAnimator.ofPropertyValuesHolder(view, scaleXValuesHolder, scaleYValuesHolder, rotateValuesHolder);
        objectAnimator.setDuration(duration);
        objectAnimator.start();
    }

}

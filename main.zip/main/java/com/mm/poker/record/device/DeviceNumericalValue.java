package com.mm.poker.record.device;

import org.opencv.core.Rect;

public class DeviceNumericalValue {


    /**
     * 1920*1080
     */
    public static final int THRESHOLD_MIN_WIDTH_OF_2_3 = 13;
    public static final int THRESHOLD_MAX_WIDTH_OF_2_3 = 30;
    public static final int THRESHOLD_MIN_HEIGHT_OF_2_3 = 15;
    public static final int THRESHOLD_HEIGHT_OF_2_3 = 30;
    public static final int THRESHOLD_TOP_START_Y_OF_2_3 = 5;


    public static final int THRESHOLD_MIN_WIDTH_OF_1 = 18;
    public static final int THRESHOLD_MAX_WIDTH_OF_1 = 35;
    public static final int THRESHOLD_MIN_HEIGHT_OF_1 = 20;
    public static final int THRESHOLD_HEIGHT_OF_1 = 40;
    public static final int THRESHOLD_TOP_START_Y_OF_1 = 30;





    //0,763,1080,511
    //277,153,515,
    //0,315,1080,88
//    public static final Rect THRESHOLD_ACTUAL_AREA_1_2_3 = new Rect(0, 746, 1080, 540);
//
//    public static final Rect THRESHOLD_ACTUAL_AREA_2_3 = new Rect(280, 163, 520 - 25, 60);
//
//    public static final Rect THRESHOLD_ACTUAL_AREA_1 = new Rect(0, 335, 1080, 88);


    public static final Rect THRESHOLD_ACTUAL_AREA_1_2_3 = new Rect(0, 763, 1080, 511);

    public static final Rect THRESHOLD_ACTUAL_AREA_2_3 = new Rect(277, 153, 515 - 20, 60);

    public static final Rect THRESHOLD_ACTUAL_AREA_1 = new Rect(0, 315, 1080, 88);

    public static int getMinWidth(int area) {
        return area == 1 ? THRESHOLD_MIN_WIDTH_OF_1 : THRESHOLD_MIN_WIDTH_OF_2_3;
    }

    public static int getMaxWidth(int area) {
        return area == 1 ? THRESHOLD_MAX_WIDTH_OF_1 : THRESHOLD_MAX_WIDTH_OF_2_3;
    }

    public static int getMinHeight(int area) {
        return area == 1 ? THRESHOLD_MIN_HEIGHT_OF_1 : THRESHOLD_MIN_HEIGHT_OF_2_3;
    }

    public static int getMaxHeight(int area) {
        return area == THRESHOLD_HEIGHT_OF_1 ? 0 : THRESHOLD_HEIGHT_OF_2_3;
    }

    public static int getStartY(int area) {
        return area == 1 ? THRESHOLD_TOP_START_Y_OF_1 : THRESHOLD_TOP_START_Y_OF_2_3;
    }
}
